"""
tracecert/cli.py

v0.4.0 — Level 4 enterprise pathway: SOC2, slop, SAST, PDF export, policy, PR bot.
"""

import json
import os
import sys
from pathlib import Path

import click

from .auditor import run_level_1_2_audit
from .cert import sign_manifest
from .scanner import generate_trace


@click.group()
@click.version_option(version="0.4.0")
def cli():
    """TraceCert: Making AI-generated software verifiable"""
    pass


# ---------------------------------------------------------------------------
# scan
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("path", type=click.Path(exists=True, path_type=Path), default=".")
@click.option("--output", "-o", default=".tracecert/cert-manifest.json", type=click.Path(path_type=Path))
@click.option("--no-hipaa", is_flag=True, default=False, help="Disable HIPAA plugin")
@click.option("--sast", is_flag=True, default=False, help="Run Semgrep/Bandit/Bearer (enterprise, slow)")
@click.option("--export-pdf", is_flag=True, default=False, help="Export PDF report + SVG badge (enterprise)")
@click.option("--level", type=int, default=3, help="Verification level requested (1-4)")
@click.option("--format", "output_format", type=click.Choice(["text", "json", "pdf"], case_sensitive=False), default="text", help="Output format for report")
@click.option("--policy", default=None, type=click.Path(path_type=Path), help="Path to policy.yaml")
@click.option("--remediate", is_flag=True, default=False, help="Print auto-remediation suggestions")
@click.option("--model", default=None, help="AI model name for provenance (e.g. claude-3.5-sonnet)")
@click.option("--prompt-file", default=None, type=click.Path(), help="Prompt file to hash for provenance")
@click.option("--json", "json_output", is_flag=True, default=False, help="Output full JSON manifest")
@click.option("--max-files", type=int, default=5000, help="Maximum number of files to scan")
@click.option("--exclude", default=None, help="Comma-separated directories to exclude")
def scan(
    path, output, no_hipaa, sast, export_pdf, level, output_format,
    policy, remediate, model, prompt_file, json_output, max_files, exclude,
):
    """Scan a directory, generate trace, and certify it."""
    path = Path(path).resolve()
    trace_file = Path(".tracecert/generated-trace.jsonl")
    trace_file.parent.mkdir(parents=True, exist_ok=True)

    click.echo(f"[scan] {path} ...", err=True)
    generate_trace(path, trace_file, max_files=max_files, exclude=exclude,
                   model=model, prompt_file=prompt_file)

    click.echo("[ok] Trace generated. Running verification...", err=True)
    return _certify(trace_file, output, no_hipaa, sast, export_pdf,
                    level, output_format, policy, remediate, json_output)


# ---------------------------------------------------------------------------
# certify
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("trace_file", type=click.Path(exists=True, path_type=Path))
@click.option("--output", "-o", default=".tracecert/cert-manifest.json", type=click.Path(path_type=Path))
@click.option("--no-hipaa", is_flag=True, default=False)
@click.option("--sast", is_flag=True, default=False, help="Run SAST scanners (enterprise)")
@click.option("--export-pdf", is_flag=True, default=False, help="Export PDF + badge (enterprise)")
@click.option("--level", type=int, default=3, help="Verification level requested (1-4)")
@click.option("--format", "output_format", type=click.Choice(["text", "json", "pdf"], case_sensitive=False), default="text", help="Output format for report")
@click.option("--policy", default=None, type=click.Path(path_type=Path))
@click.option("--remediate", is_flag=True, default=False)
@click.option("--json", "json_output", is_flag=True, default=False)
def certify(trace_file, output, no_hipaa, sast, export_pdf, level, output_format, policy, remediate, json_output):
    """Certify an existing Agent Trace file."""
    return _certify(trace_file, output, no_hipaa, sast, export_pdf,
                    level, output_format, policy, remediate, json_output)


# ---------------------------------------------------------------------------
# pr-check
# ---------------------------------------------------------------------------

@cli.command("pr-check")
@click.option("--manifest", default=".tracecert/cert-manifest.json",
              type=click.Path(path_type=Path), help="Manifest to evaluate")
@click.option("--pr", default=None, help="PR number to post comment on")
@click.option("--sha", default=None, help="Commit SHA for status check")
@click.option("--repo", default=None, help="owner/repo (default: GITHUB_REPOSITORY env)")
@click.option("--threshold", default=90, type=int, help="Minimum score to pass (default 90)")
@click.option("--policy", default=None, type=click.Path(path_type=Path))
def pr_check(manifest, pr, sha, repo, threshold, policy):
    """Post compliance report to a GitHub PR and set commit status."""
    from .tier import require_enterprise
    require_enterprise("github_bot")

    manifest_path = Path(manifest)
    if not manifest_path.exists():
        raise click.ClickException(f"Manifest not found: {manifest_path}")

    signed = json.loads(manifest_path.read_text())

    from .policy import load_policy, enforce_policy
    from .remediation import get_remediations
    from .github_bot import run_pr_check

    pol = load_policy(Path(policy) if policy else None)
    policy_result = enforce_policy(signed, pol)
    remediations = get_remediations(signed)

    result = run_pr_check(
        signed, policy_result["violations"], remediations,
        pr_number=pr, commit_sha=sha, repo=repo, threshold=threshold,
    )

    icon = "[PASS]" if result["passed"] else "[FAIL]"
    click.echo(f"{icon} PR check {'passed' if result['passed'] else 'FAILED'} "
               f"(score={result['score']}, threshold={threshold})")
    if not result["passed"]:
        sys.exit(1)


# ---------------------------------------------------------------------------
# shared implementation
# ---------------------------------------------------------------------------

def _certify(trace_file, output, no_hipaa, sast, export_pdf, level, output_format, policy, remediate, json_output):
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)

    if level == 4:
        from .tier import require_enterprise
        require_enterprise("level4")

    if sast:
        from .tier import require_enterprise
        require_enterprise("sast_integration")

    if output_format == "pdf":
        export_pdf = True
    if output_format == "json":
        json_output = True

    if export_pdf:
        from .tier import require_enterprise
        require_enterprise("pdf_export")

    try:
        manifest_dict = run_level_1_2_audit(
            trace_file, enable_hipaa=not no_hipaa, enable_sast=sast,
        )
        signed = sign_manifest(manifest_dict, output)

        # Policy enforcement
        violations = []
        if policy or Path(".tracecert/policy.yaml").exists():
            from .policy import load_policy, enforce_policy
            pol = load_policy(Path(policy) if policy else None)
            policy_result = enforce_policy(signed, pol)
            violations = policy_result["violations"]

        # Remediations
        fix_suggestions = []
        if remediate:
            from .remediation import get_remediations
            fix_suggestions = get_remediations(signed)

        # PDF + badge
        if export_pdf:
            from .export import export_pdf as _pdf, export_badge
            pdf_out = _pdf(signed, output.parent)
            badge_out = export_badge(signed, output.parent)
            click.echo(f"[report] {pdf_out}")
            click.echo(f"[badge]  {badge_out}")

        if json_output:
            click.echo(json.dumps(signed, indent=2))
            if violations:
                click.echo(json.dumps({"policy_violations": violations}), err=True)
            return

        _print_summary(signed, violations, fix_suggestions, output)

        if violations:
            click.echo("\n[FAIL] Policy violations detected -- CI gate would block merge.", err=True)
            sys.exit(1)

    except PermissionError as e:
        click.echo(f"[locked] {e}", err=True)
        sys.exit(2)
    except Exception as e:
        click.echo(f"[error] {e}", err=True)
        raise click.ClickException(str(e))


_DISCLAIMER = (
    "TraceCert provides verification signals and mappings to common frameworks\n"
    "(HIPAA Security Rule §164.312, SOC 2 Trust Services Criteria, OWASP, etc.).\n"
    "It is NOT a substitute for legal advice, official risk analysis, or third-party\n"
    "audits. Final compliance responsibility lies with your organization and qualified\n"
    "auditors."
)


def _print_summary(signed, violations, fix_suggestions, output):
    cert = signed["certification"]
    summary = cert.get("summary", {})
    bar = "=" * 80
    level = cert.get("highest_level", 0)

    click.echo(f"\n{bar}")
    click.echo(f"TraceCert Level {level} Verification -- Manifest Signed")
    click.echo(bar)
    click.echo(f"Verification Level  : {level}")
    click.echo(f"Levels Verified     : {cert.get('levels_verified', [])}")
    click.echo(f"AI-Generated        : {summary.get('ai_percentage', 0)}% ({summary.get('lines_ai_generated', 0):,} lines)")
    click.echo(f"Verification Score  : {summary.get('compliance_score', 0)}/100")
    click.echo(f"Records Processed   : {summary.get('records_processed', 0)}")
    click.echo(f"Unique Files        : {summary.get('unique_files', 0)}")
    click.echo(f"Secrets Found       : {summary.get('secrets_found', 0)}")
    click.echo(f"HIPAA-ready checks  : {summary.get('hipaa_enabled', False)}")

    for att in signed.get("attestations", []):
        ptype = att.get("predicateType", "")
        pred = att.get("predicate", {})
        if "healthcare" in ptype:
            phi = pred.get('risk_level', '?')
            click.echo(f"PHI Risk Score      : {pred.get('compliance_score', 0)}/100  [PHI risk: {phi} per our analysis]")
            click.echo(f"HIPAA-ready         : {pred.get('hipaa_ready', False)}  (matches our HIPAA-ready rule set)")
        if "soc2" in ptype and "level4" not in ptype:
            click.echo(f"SOC2 TSC Alignment  : {pred.get('soc2_score', 0)}/100  [{pred.get('grade', '?')}]  (aligns with SOC 2 TSC mapping)")
            if pred.get("controls_failed"):
                click.echo(f"SOC2 TSC Gaps       : {', '.join(pred['controls_failed'])}")
        if "slop" in ptype:
            click.echo(f"AI Quality Grade    : {pred.get('ai_quality_grade', '?')}  (slop score {pred.get('slop_score', 0)})")
        if "sast" in ptype:
            click.echo(f"SAST Findings       : {pred.get('total_findings', 0)} total, {pred.get('high_severity', 0)} high")
        if "level4" in ptype:
            click.echo(f"SOC2 + HIPAA Signal : Level 4 -- SOC2 TSC + HIPAA s164.312 mappings present")

    click.echo(f"Provenance Entries  : {len(signed.get('provenance', []))}")
    click.echo(f"Signature Type      : {signed.get('signature', {}).get('type', 'mvp').upper()}")
    click.echo(f"Output File         : {output}")

    if violations:
        click.echo("\nPolicy Violations   :")
        for v in violations:
            click.echo(f"  [x] {v}")

    if fix_suggestions:
        click.echo("\nRemediation Suggestions (suggested only -- review before applying):")
        for r in fix_suggestions:
            click.echo(f"  * {r['title']}: {r['fix']}")
            if r.get("example"):
                click.echo(f"    -> {r['example']}")

    click.echo(f"\n{bar}")
    click.echo(_DISCLAIMER)
    click.echo(bar)


if __name__ == "__main__":
    cli()
