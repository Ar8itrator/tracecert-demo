"""
tracecert/policy.py

Policy-as-code enforcement for CI/CD gating.
Reads .tracecert/policy.yaml; falls back to built-in defaults.

Example policy.yaml:
  min_score: 85
  block_on_secrets: true
  rules:
    - name: no_high_sast
      field: sast_high_severity
      op: lte
      value: 0
    - name: min_soc2
      field: soc2_score
      op: gte
      value: 60
"""

from pathlib import Path
from typing import Dict, Any, List

DEFAULT_POLICY_PATH = Path(".tracecert/policy.yaml")

_DEFAULTS: Dict[str, Any] = {
    "min_score": 80,
    "block_on_secrets": True,
    "rules": [],
}


def _parse_yaml_minimal(text: str) -> Dict[str, Any]:
    """Minimal YAML parser for flat key:value (no PyYAML dependency)."""
    result: Dict[str, Any] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        k, _, v = line.partition(":")
        v = v.strip()
        if v.lower() in ("true", "yes"):
            result[k.strip()] = True
        elif v.lower() in ("false", "no"):
            result[k.strip()] = False
        else:
            try:
                result[k.strip()] = int(v)
            except ValueError:
                result[k.strip()] = v
    return result


def load_policy(policy_file: Path = None) -> Dict[str, Any]:
    """Load policy from YAML file; return defaults if absent."""
    path = policy_file or DEFAULT_POLICY_PATH
    if not path.exists():
        return _DEFAULTS.copy()

    text = path.read_text(encoding="utf-8")
    try:
        import yaml  # type: ignore
        data = yaml.safe_load(text) or {}
    except ImportError:
        data = _parse_yaml_minimal(text)

    return {**_DEFAULTS, **data}


def enforce_policy(manifest: Dict[str, Any], policy: Dict[str, Any]) -> Dict[str, Any]:
    """
    Evaluate policy against manifest summary + attestation fields.
    Returns {"passed": bool, "violations": list[str]}.
    """
    violations: List[str] = []
    summary = manifest.get("certification", {}).get("summary", {})

    # Flatten attestation predicates into summary for rule evaluation
    flat: Dict[str, Any] = dict(summary)
    for att in manifest.get("attestations", []):
        pred = att.get("predicate", {})
        domain = att.get("predicateType", "").split("/")[-2]
        for k, v in pred.items():
            flat[f"{domain}_{k}"] = v

    score = flat.get("compliance_score", 0)
    min_score = policy.get("min_score", 80)
    if score < min_score:
        violations.append(f"Compliance score {score} below minimum {min_score}")

    if policy.get("block_on_secrets", True) and flat.get("secrets_found", 0) > 0:
        violations.append(f"Secrets detected: {flat['secrets_found']} found")

    for rule in policy.get("rules", []):
        field = rule.get("field", "")
        op = rule.get("op", "gte")
        threshold = rule.get("value", 0)
        actual = flat.get(field, 0)
        name = rule.get("name", field)

        if op == "gte" and actual < threshold:
            violations.append(f"Rule '{name}': {field}={actual} < {threshold}")
        elif op == "lte" and actual > threshold:
            violations.append(f"Rule '{name}': {field}={actual} > {threshold}")
        elif op == "eq" and actual != threshold:
            violations.append(f"Rule '{name}': {field}={actual} != {threshold}")

    return {"passed": len(violations) == 0, "violations": violations}
