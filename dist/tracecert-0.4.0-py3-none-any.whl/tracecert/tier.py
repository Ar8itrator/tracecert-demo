"""
tracecert/tier.py

Feature tiering: free vs enterprise.
Set TRACECERT_TIER=enterprise to unlock all features.
"""

import os
from typing import Set

FREE_FEATURES: Set[str] = {
    "basic_scan", "level1", "level2", "hipaa_basic",
    "slop_detection", "remediation_preview", "soc2_basic",
}

ENTERPRISE_FEATURES: Set[str] = {
    "sast_integration", "pdf_export", "badge_export",
    "github_bot", "policy_as_code", "otel_audit",
    "rbac", "vpc_selfhost", "level4",
}


def get_tier() -> str:
    return os.environ.get("TRACECERT_TIER", "free").lower()


def feature_enabled(feature: str) -> bool:
    tier = get_tier()
    if tier in ("enterprise", "pro"):
        return True
    return feature in FREE_FEATURES


def require_enterprise(feature: str) -> None:
    if not feature_enabled(feature):
        raise PermissionError(
            f"'{feature}' requires enterprise tier. "
            "Set TRACECERT_TIER=enterprise or visit https://tracecert.dev/pricing"
        )
