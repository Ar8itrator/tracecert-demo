"""
tracecert/export.py

Compliance badge (SVG) and PDF report export.
PDF requires fpdf2 (optional); falls back to .txt if not installed.
"""

from pathlib import Path
from typing import Dict, Any
from datetime import datetime

DISCLAIMER = (
    "TraceCert provides verification signals and mappings to common frameworks "
    "(HIPAA Security Rule §164.312, SOC 2 Trust Services Criteria, OWASP, etc.). "
    "It is NOT a substitute for legal advice, official risk analysis, or third-party audits. "
    "Final compliance responsibility lies with your organization and qualified auditors."
)


def export_badge(manifest: Dict[str, Any], output_dir: Path) -> Path:
    """Generate an SVG compliance badge."""
    cert = manifest.get("certification", {})
    level = cert.get("highest_level", 0)
    score = cert.get("summary", {}).get("compliance_score", 0)
    color = "#4CAF50" if score >= 90 else "#FF9800" if score >= 70 else "#F44336"

    svg = (
        '<svg xmlns="http://www.w3.org/2000/svg" width="160" height="20">'
        '<rect width="90" height="20" fill="#555"/>'
        f'<rect x="90" width="70" height="20" fill="{color}"/>'
        '<text x="45" y="14" fill="#fff" font-size="11" font-family="sans-serif" '
        f'text-anchor="middle">TraceCert L{level}</text>'
        '<text x="125" y="14" fill="#fff" font-size="11" font-family="sans-serif" '
        f'text-anchor="middle">{score}/100</text>'
        "</svg>"
    )
    out = output_dir / "tracecert-badge.svg"
    out.write_text(svg, encoding="utf-8")
    return out


def _build_report_lines(manifest: Dict[str, Any]) -> list:
    cert = manifest.get("certification", {})
    summary = cert.get("summary", {})
    level = cert.get("highest_level", 0)
    lines = [
        DISCLAIMER.replace("—", "-"),
        "",
        f"TraceCert Level {level} Verification Report",
        f"Generated : {manifest.get('generated_at', datetime.utcnow().isoformat())}",
        f"Trace     : {manifest.get('trace_file', 'unknown')}",
        "=" * 60,
        f"Verification Level      : {level}",
        f"Levels Verified         : {cert.get('levels_verified', [])}",
        f"Verification Score      : {summary.get('compliance_score', 0)}/100",
        f"AI Generated            : {summary.get('ai_percentage', 0)}%",
        f"Secrets Found           : {summary.get('secrets_found', 0)}",
        f"HIPAA-ready checks      : {summary.get('hipaa_enabled', False)}",
        f"SOC2 TSC alignment      : {summary.get('soc2_ready', False)} (aligns with SOC 2 TSC mapping)",
        "",
        "Attestation Details:",
    ]
    for att in manifest.get("attestations", []):
        lines.append(f"  [{att.get('predicateType', '')}]")
        for k, v in att.get("predicate", {}).items():
            lines.append(f"    {k}: {v}")
    lines.extend(["", DISCLAIMER.replace("—", "-")])
    return lines


def export_pdf(manifest: Dict[str, Any], output_dir: Path) -> Path:
    """Export PDF report (fpdf2) or fallback to .txt."""
    output_dir.mkdir(parents=True, exist_ok=True)
    lines = _build_report_lines(manifest)

    try:
        from fpdf import FPDF  # type: ignore
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Helvetica", size=11)
        for line in lines:
            pdf.cell(0, 7, line, ln=True)
        out = output_dir / "tracecert-report.pdf"
        pdf.output(str(out))
        return out
    except ImportError:
        out = output_dir / "tracecert-report.txt"
        out.write_text("\n".join(lines), encoding="utf-8")
        return out
