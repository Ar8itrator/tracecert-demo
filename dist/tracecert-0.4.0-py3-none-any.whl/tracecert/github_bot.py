"""
tracecert/github_bot.py

GitHub PR bot: post compliance reports and optionally block merges.
Uses the `gh` CLI (must be installed + authenticated).
"""

import json
import os
import subprocess
from typing import Dict, Any, List, Optional

DEFAULT_THRESHOLD = 90

_DISCLAIMER = (
    "> **Disclaimer:** TraceCert provides verification signals and mappings to common frameworks "
    "(HIPAA Security Rule §164.312, SOC 2 Trust Services Criteria, OWASP, etc.). "
    "It is NOT a substitute for legal advice, official risk analysis, or third-party audits. "
    "Final compliance responsibility lies with your organization and qualified auditors."
)


def _gh(args: List[str], stdin: Optional[str] = None) -> bool:
    try:
        subprocess.run(
            ["gh"] + args,
            input=stdin, text=True, check=True, capture_output=True,
        )
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False


def _post_comment(pr: str, body: str, repo: Optional[str]) -> bool:
    args = ["pr", "comment", pr, "--body", body]
    if repo:
        args += ["--repo", repo]
    return _gh(args)


def _set_commit_status(sha: str, state: str, description: str, repo: Optional[str]) -> bool:
    repo_slug = repo or os.environ.get("GITHUB_REPOSITORY", "")
    if not repo_slug:
        return False
    payload = json.dumps({
        "state": state,
        "description": description[:139],
        "context": "tracecert/compliance",
    })
    return _gh(["api", f"repos/{repo_slug}/statuses/{sha}", "--method", "POST", "--input", "-"], stdin=payload)


def build_pr_body(
    manifest: Dict[str, Any],
    violations: List[str],
    remediations: List[Dict[str, str]],
    threshold: int = DEFAULT_THRESHOLD,
) -> str:
    cert = manifest.get("certification", {})
    summary = cert.get("summary", {})
    score = summary.get("compliance_score", 0)
    level = cert.get("highest_level", 0)
    passed = score >= threshold and not violations
    icon = "✅" if passed else "❌"
    verdict = "Merge approved" if passed else f"Merge blocked (score < {threshold})"

    rows = [
        f"| AI Generated | {summary.get('ai_percentage', 0)}% |",
        f"| Secrets Found | {summary.get('secrets_found', 0)} |",
        f"| HIPAA-ready rule set | {summary.get('hipaa_ready', False)} |",
        f"| Verification Score | **{score}/100** |",
    ]

    if summary.get("soc2_ready"):
        rows.append("| SOC2 TSC alignment | matches our mapping |")

    for att in manifest.get("attestations", []):
        pred = att.get("predicate", {})
        ptype = att.get("predicateType", "")
        if "soc2" in ptype and "level4" not in ptype:
            rows.append(f"| SOC2 TSC Alignment Score | {pred.get('soc2_score', '?')}/100 |")
        if "slop" in ptype:
            rows.append(f"| AI Quality Grade | {pred.get('ai_quality_grade', '?')} |")
        if "healthcare" in ptype:
            rows.append(f"| PHI Risk (per our analysis) | {pred.get('risk_level', '?')} |")

    lines = [
        _DISCLAIMER,
        "",
        f"## {icon} TraceCert Level {level} Verification | {score}/100 | {verdict}",
        "",
        "Matches our HIPAA-ready rule set and aligns with SOC 2 TSC mapping.",
        "",
        "| Metric | Value |",
        "|--------|-------|",
        *rows,
        "",
    ]

    if violations:
        lines += ["### ❌ Policy Violations", ""]
        lines += [f"- {v}" for v in violations]
        lines.append("")

    if remediations:
        lines += ["### Suggested Fixes (review before applying)", ""]
        for r in remediations[:3]:
            lines.append(f"**{r['title']}**: {r['fix']}")
            if r.get("example"):
                lines += ["```", r["example"], "```"]
        lines.append("")

    lines += [_DISCLAIMER, "", f"*[TraceCert](https://tracecert.ai) - {verdict}*"]
    return "\n".join(lines)


def run_pr_check(
    manifest: Dict[str, Any],
    violations: List[str],
    remediations: List[Dict[str, str]],
    pr_number: Optional[str] = None,
    commit_sha: Optional[str] = None,
    repo: Optional[str] = None,
    threshold: int = DEFAULT_THRESHOLD,
) -> Dict[str, Any]:
    """Post PR comment + commit status. Returns pass/fail dict."""
    score = manifest.get("certification", {}).get("summary", {}).get("compliance_score", 0)
    passed = score >= threshold and not violations

    if pr_number:
        body = build_pr_body(manifest, violations, remediations, threshold)
        _post_comment(pr_number, body, repo)

    if commit_sha:
        state = "success" if passed else "failure"
        _set_commit_status(commit_sha, state, f"TraceCert {score}/100", repo)

    return {"passed": passed, "score": score, "violations": violations}
