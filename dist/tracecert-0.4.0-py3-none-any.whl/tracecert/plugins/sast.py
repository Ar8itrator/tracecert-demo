"""
tracecert/plugins/sast.py

SAST plugin: wraps Semgrep, Bandit, Bearer (all optional).
Only runs when --sast flag is passed; requires enterprise tier.
"""

import json
import subprocess
from pathlib import Path
from typing import Dict, Any, List

from .base import Plugin


def _run(cmd: List[str], timeout: int = 90) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.stdout or ""
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""


class SASTPlugin(Plugin):
    name = "SAST"
    domain = "sast"
    description = "Semgrep, Bandit, Bearer SAST - runs on repo root derived from trace location"

    def _bandit(self, path: str) -> List[Dict]:
        out = _run(["bandit", "-r", path, "-f", "json", "-q"])
        try:
            return json.loads(out).get("results", [])
        except (json.JSONDecodeError, AttributeError):
            return []

    def _semgrep(self, path: str) -> List[Dict]:
        out = _run(["semgrep", "--config=auto", "--json", "--quiet", path], timeout=120)
        try:
            return json.loads(out).get("results", [])
        except (json.JSONDecodeError, AttributeError):
            return []

    def _bearer(self, path: str) -> List[Dict]:
        out = _run(["bearer", "scan", path, "--format", "json", "--quiet"], timeout=120)
        try:
            data = json.loads(out)
            # bearer output varies by version
            return data.get("findings", data.get("risks", []))
        except (json.JSONDecodeError, AttributeError):
            return []

    def run(self, trace_file: Path, trace_data: Dict[str, Any]) -> Dict[str, Any]:
        # Resolve repo root: two levels up from .tracecert/
        scan_path = str(trace_file.parent.parent)

        bandit = self._bandit(scan_path)
        semgrep = self._semgrep(scan_path)
        bearer = self._bearer(scan_path)

        high = sum(1 for r in bandit if r.get("issue_severity") == "HIGH")
        medium = sum(1 for r in bandit if r.get("issue_severity") == "MEDIUM")

        score = max(40, 100 - (high * 20) - (medium * 5) - len(semgrep) * 3 - len(bearer) * 2)
        tools_run = [t for t, r in [("bandit", bandit), ("semgrep", semgrep), ("bearer", bearer)] if r]

        return {
            "bandit_findings": len(bandit),
            "semgrep_findings": len(semgrep),
            "bearer_findings": len(bearer),
            "high_severity": high,
            "medium_severity": medium,
            "total_findings": len(bandit) + len(semgrep) + len(bearer),
            "sast_score": round(score),
            "tools_run": tools_run,
        }
