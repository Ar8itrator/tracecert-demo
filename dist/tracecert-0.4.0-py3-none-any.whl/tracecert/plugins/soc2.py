"""
tracecert/plugins/soc2.py

SOC2 Type 2 grading plugin.
Scores against CC6/CC7/CC8/A1/C1/PI1/P1 controls via keyword presence.
Fast regex pass — runs by default.
"""

from pathlib import Path
from typing import Dict, Any, List

from .base import Plugin

# SOC2 controls → evidence keywords
_CONTROLS: Dict[str, List[str]] = {
    "CC6":  ["encrypt", "tls", "ssl", "kms", "vault", "secret_manager", "rbac", "iam"],
    "CC7":  ["log", "audit", "monitor", "alert", "siem", "cloudwatch", "datadog"],
    "CC8":  ["deploy", "release", "pipeline", "ci", "cd", "migration", "rollback"],
    "A1":   ["timeout", "retry", "circuit_breaker", "health_check", "rate_limit"],
    "C1":   ["encrypt", "hash", "bcrypt", "argon2", "pbkdf2", "fernet", "aes"],
    "PI1":  ["validate", "assert", "test", "verify", "checksum", "schema"],
    "P1":   ["gdpr", "ccpa", "consent", "privacy", "pii", "redact", "anonymize"],
}


class SOC2Plugin(Plugin):
    name = "SOC2"
    domain = "soc2"
    description = "SOC2 Type 2 control scoring: CC6/CC7/CC8/A1/C1/PI1/P1"

    def run(self, trace_file: Path, trace_data: Dict[str, Any]) -> Dict[str, Any]:
        raw = trace_data.get("raw_content", "").lower()
        control_scores: Dict[str, int] = {}

        for control, keywords in _CONTROLS.items():
            hits = sum(1 for kw in keywords if kw in raw)
            control_scores[control] = min(100, hits * 15)

        overall = round(sum(control_scores.values()) / len(control_scores))
        passed = [c for c, s in control_scores.items() if s >= 30]
        failed = [c for c, s in control_scores.items() if s < 30]

        return {
            "soc2_score": overall,
            "controls_passed": passed,
            "controls_failed": failed,
            "control_scores": control_scores,
            "soc2_type2_ready": overall >= 60 and len(failed) <= 2,
            "grade": "Pass" if overall >= 60 else "Fail",
        }
