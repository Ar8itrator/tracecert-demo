"""
tracecert/plugins/slop.py

AI "slop" detection: patterns humans rarely write but LLMs over-produce.
Fast regex pass over raw_content - runs by default with every scan.
"""

import re
from pathlib import Path
from typing import Dict, Any, List, Tuple

from .base import Plugin

# (pattern, label) - each represents an AI-specific smell
_PATTERNS: List[Tuple[str, str]] = [
    (r"# TODO[:\s]", "todo_comment"),
    (r"# FIXME[:\s]", "fixme_comment"),
    (r"^\s*pass\s*$", "empty_pass"),
    (r"except\s*:", "bare_except"),
    (r'print\(f?["\'].*[Dd]ebug', "debug_print"),
    (r"raise NotImplementedError", "stub_not_implemented"),
    (r"def \w+\([^)]*\):\s*\.\.\.", "ellipsis_stub"),
    (r"# type: ignore", "type_ignore"),
    (r"\beval\s*\(|\bexec\s*\(", "eval_exec"),
    (r"time\.sleep\(\d+\)", "hardcoded_sleep"),
    (r"#\s*(noqa|pylint: disable)", "suppressed_linter"),
    (r"logging\.debug\(.*password|logging\.info\(.*secret", "logged_secret"),
    (r"import \*", "wildcard_import"),
    (r"except Exception as e:\s*pass", "swallowed_exception"),
]

_CAMEL_RE = re.compile(r"\b[a-z][a-z0-9]*[A-Z]\w*\b")
_SNAKE_RE = re.compile(r"\b[a-z][a-z0-9]*_[a-z][a-z0-9_]*\b")


class SlopPlugin(Plugin):
    name = "SlopDetector"
    domain = "slop"
    description = "Detects AI-specific code patterns: stubs, suppressed errors, inconsistent style"

    def run(self, trace_file: Path, trace_data: Dict[str, Any]) -> Dict[str, Any]:
        raw = trace_data.get("raw_content", "")
        findings: Dict[str, int] = {}

        for pattern, label in _PATTERNS:
            count = len(re.findall(pattern, raw, re.MULTILINE | re.IGNORECASE))
            if count:
                findings[label] = count

        # Mixed naming convention check
        camel = len(_CAMEL_RE.findall(raw))
        snake = len(_SNAKE_RE.findall(raw))
        if camel > 5 and snake > 5:
            ratio = min(camel, snake) / max(camel, snake)
            if ratio > 0.25:
                findings["mixed_naming_convention"] = camel

        total = sum(findings.values())
        slop_score = max(40, 100 - total * 2)
        grade = "A" if slop_score >= 90 else "B" if slop_score >= 75 else "C" if slop_score >= 60 else "D"

        return {
            "slop_findings": findings,
            "total_slop_indicators": total,
            "slop_score": round(slop_score),
            "ai_quality_grade": grade,
        }
