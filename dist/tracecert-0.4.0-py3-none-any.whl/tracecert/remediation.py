"""
tracecert/remediation.py

Auto-remediation previews: maps manifest findings to targeted fix suggestions.
"""

from typing import Dict, Any, List

_FIXES: Dict[str, Dict[str, str]] = {
    "secrets_found": {
        "title": "Exposed secrets",
        "fix": "Move credentials to environment variables or a secrets manager.",
        "example": "os.environ['API_KEY']  # never hardcode",
    },
    "bare_except": {
        "title": "Bare except clause",
        "fix": "Catch specific exception types.",
        "example": "except (ValueError, KeyError) as e: ...",
    },
    "eval_exec": {
        "title": "eval()/exec() usage",
        "fix": "Use ast.literal_eval() for data; avoid dynamic code execution.",
        "example": "import ast; ast.literal_eval(user_input)",
    },
    "stub_not_implemented": {
        "title": "Unimplemented stubs",
        "fix": "Implement or delete raise NotImplementedError placeholders.",
        "example": "# Complete the implementation or remove the method",
    },
    "debug_print": {
        "title": "Debug print statements",
        "fix": "Replace with structured logging.",
        "example": "import logging; logging.debug('msg: %s', value)",
    },
    "swallowed_exception": {
        "title": "Swallowed exceptions",
        "fix": "Log or re-raise; never silently discard errors.",
        "example": "except Exception as e: logging.error('Failed: %s', e); raise",
    },
    "wildcard_import": {
        "title": "Wildcard imports",
        "fix": "Import only what you need to avoid namespace pollution.",
        "example": "from module import SpecificClass, specific_func",
    },
    "soc2_controls_failed": {
        "title": "SOC2 control gaps",
        "fix": "Add audit logging (CC7), encryption (C1), input validation (PI1).",
        "example": "logging.getLogger('audit').info('action=%s user=%s', action, user_id)",
    },
    "hipaa_risky_prompts": {
        "title": "HIPAA PHI risk patterns",
        "fix": "Encrypt PHI at rest and in transit; never log patient identifiers.",
        "example": "# Use FHIR-R4 compliant storage; redact PHI before logging",
    },
    "mixed_naming_convention": {
        "title": "Inconsistent naming conventions",
        "fix": "Standardize on snake_case for Python (PEP 8).",
        "example": "# Run: ruff check --select N . to auto-detect",
    },
}


def get_remediations(manifest: Dict[str, Any]) -> List[Dict[str, str]]:
    """Return deduplicated fix suggestions derived from manifest findings."""
    summary = manifest.get("certification", {}).get("summary", {})
    keys: List[str] = []

    if summary.get("secrets_found", 0) > 0:
        keys.append("secrets_found")

    for att in manifest.get("attestations", []):
        pred = att.get("predicate", {})

        # Slop findings
        for slop_key in pred.get("slop_findings", {}):
            if slop_key in _FIXES:
                keys.append(slop_key)

        # SOC2
        if pred.get("controls_failed"):
            keys.append("soc2_controls_failed")

        # HIPAA
        if pred.get("risky_prompts_detected", 0) > 0:
            keys.append("hipaa_risky_prompts")

    seen: set = set()
    result: List[Dict[str, str]] = []
    for k in keys:
        if k not in seen and k in _FIXES:
            seen.add(k)
            result.append(_FIXES[k])

    return result
