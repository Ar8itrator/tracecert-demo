"""
TraceCert: Certificate generation and audit trail verification for AI-generated code.
"""

__version__ = "0.4.0"
__author__ = "Ar8itrat0r + Grok"
__description__ = "Making AI-generated software verifiable with continuous audit and certification levels"

# Only expose the public CLI and version
from .cli import cli

__all__ = ["cli", "__version__", "__author__", "__description__"]