"""
tracecert/auditor.py

Parses Agent Trace, runs Level 1/2/3+ plugins including SOC2 and slop detection.
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional

from .models import Attestation
from .plugins.base import Plugin
from .plugins.healthcare import HealthcarePlugin
from .plugins.slop import SlopPlugin
from .plugins.soc2 import SOC2Plugin


def parse_agent_trace(trace_file: Path) -> Dict[str, Any]:
    """Parse the exact Agent Trace format from your sample."""
    records: List[Dict] = []
    ai_lines = 0
    total_lines = 0
    files_touched = set()
    models_used = set()
    raw_content = ""

    with open(trace_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
                records.append(record)

                # Extract model
                if model := record.get("metadata", {}).get("model"):
                    models_used.add(model)

                # Process files array - this was the main bug
                for file_entry in record.get("files", []):
                    path = file_entry.get("path", "")
                    if path:
                        files_touched.add(path)
                    
                    if file_entry.get("ai_generated", False):
                        # Use 50 lines as reasonable default since trace doesn't specify count
                        ai_lines += file_entry.get("lines", 50)
                        total_lines += file_entry.get("lines", 50)
                    else:
                        total_lines += 10

                # Collect any content for scanning (in real traces this may be in "content" or "prompt")
                content = str(record.get("content", "")) + str(record.get("prompt", ""))
                raw_content += content + "\n"

            except (json.JSONDecodeError, TypeError, KeyError):
                continue

    # Collect per-file provenance (model + content_hash per record)
    provenance_log = []
    for rec in records:
        meta = rec.get("metadata", {})
        for f in rec.get("files", []):
            entry = {
                "file": f.get("path", ""),
                "model": meta.get("model", "unknown"),
                "timestamp": rec.get("timestamp", ""),
                "prompt": rec.get("prompt", ""),
                "line_estimate": f.get("lines", 50),
            }
            if "prompt_hash" in meta:
                entry["prompt_hash"] = meta["prompt_hash"]
            if "content_hash" in meta:
                entry["content_hash"] = meta["content_hash"]
            if rec.get("content"):
                entry["content_sample"] = str(rec.get("content"))[:200]
            provenance_log.append(entry)

    return {
        "records": records,
        "ai_lines": ai_lines,
        "total_lines": max(total_lines, 1),
        "files_touched": files_touched,
        "models_used": models_used,
        "raw_content": raw_content,
        "provenance_log": provenance_log,
    }


def run_level_1_2_audit(
    trace_file: Path,
    plugins: Optional[List[Plugin]] = None,
    enable_hipaa: bool = True,
    enable_sast: bool = False,
) -> dict:
    """Main audit function. SAST is opt-in (slow); slop/SOC2 always run."""

    if plugins is None:
        plugins = [SlopPlugin(), SOC2Plugin()]
        if enable_hipaa:
            plugins.append(HealthcarePlugin())
        if enable_sast:
            from .plugins.sast import SASTPlugin
            plugins.append(SASTPlugin())

    data = parse_agent_trace(trace_file)

    if not data["records"]:
        raise ValueError("No valid records found in trace file")

    ai_percentage = min(round((data["ai_lines"] / data["total_lines"]) * 100, 1), 99.0)

    # Basic secret detection
    secrets_found = (
        data["raw_content"].lower().count("sk-") +
        sum(1 for kw in ["password=", "secret=", "api_key=", "private_key"]
            if kw in data["raw_content"].lower())
    )

    compliance_score = max(88 - (secrets_found * 15), 60)
    compliance_score = round(compliance_score, 1)

    # Base attestations
    attestations = [
        Attestation(
            predicateType="https://tracecert.dev/predicates/level1/v1",
            predicate={
                "quality_checks_passed": True,
                "records_processed": len(data["records"]),
                "unique_files": len(data["files_touched"]),
                "ai_percentage": ai_percentage,
                "models_used": list(data["models_used"]),
                "provenance_entries": len(data.get("provenance_log", [])),
            }
        ),
        Attestation(
            predicateType="https://tracecert.dev/predicates/level2/v1",
            predicate={
                "security": {
                    "secrets_found": secrets_found,
                    "owasp_no_secrets_detected": secrets_found == 0,
                },
                "provenance": {
                    "trace_file": trace_file.name,
                    "records": len(data["records"])
                }
            }
        )
    ]

    # Run Level 3 plugins
    level3_attestations = []
    plugin_results = {}
    plugin_names = []

    for plugin in plugins:
        try:
            result = plugin.run(trace_file, data)
            plugin_results[plugin.domain] = result
            level3_attestations.append(plugin.get_attestation(result))
            plugin_names.append(plugin.name)
        except Exception as e:
            import sys as _sys
            _sys.stderr.write(f"[warn] Plugin {getattr(plugin, 'name', 'unknown')} failed: {e}\n")

    level4_attestation = None
    soc2_ready = False
    hipaa_ready = False
    if "soc2" in plugin_results and "healthcare" in plugin_results:
        soc2_ready = plugin_results["soc2"].get("soc2_score", 0) >= 70
        hipaa_ready = plugin_results["healthcare"].get("hipaa_ready", False)
        if soc2_ready and hipaa_ready:
            level4_attestation = {
                "predicateType": "https://tracecert.dev/predicates/level4/verification/v1",
                "predicate": {
                    "verification_level": 4,
                    "soc2_tsc_mapping": {
                        "CC6": "encryption + access controls",
                        "CC7": "audit logging",
                        "CC8": "change management",
                        "A1": "resilience",
                        "C1": "crypto practices",
                        "PI1": "validation",
                        "P1": "privacy",
                    },
                    "hipaa_164_312_mapping": {
                        "164.312(a)(2)(iv)": "encryption",
                        "164.312(b)": "audit controls",
                        "164.312(c)(1)": "integrity",
                    },
                    "soc2_score": plugin_results["soc2"].get("soc2_score", 0),
                    "hipaa_compliance_score": plugin_results["healthcare"].get("compliance_score", 0),
                    "hipaa_ready": hipaa_ready,
                    "soc2_ready": soc2_ready,
                },
            }
            level3_attestations.append(level4_attestation)

    highest_level = 4 if level4_attestation else 3 if level3_attestations else 2

    import hashlib as _hl
    trace_digest = "sha256:" + _hl.sha256(trace_file.read_bytes()).hexdigest()

    manifest_dict = {
        "version": "1.0.0",
        "spec": "tracecert+v1",
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "trace_file": trace_file.name,
        "trace_digest": trace_digest,
        "certification": {
            "highest_level": highest_level,
            "levels_verified": ([1, 2, 3, 4] if level4_attestation else [1, 2, 3]) if level3_attestations else [1, 2],
            "summary": {
                "lines_ai_generated": data["ai_lines"],
                "total_lines_estimated": data["total_lines"],
                "ai_percentage": ai_percentage,
                "compliance_score": compliance_score,
                "records_processed": len(data["records"]),
                "unique_files": len(data["files_touched"]),
                "secrets_found": secrets_found,
                "models_used": len(data["models_used"]),
                "plugins_run": plugin_names,
                "hipaa_enabled": any(p.name.lower() == "healthcare" for p in plugins),
                "soc2_ready": soc2_ready,
                "hipaa_ready": hipaa_ready,
                "verification_level": highest_level,
            }
        },
        "provenance": data.get("provenance_log", []),
        "attestations": [a.model_dump() for a in attestations] + level3_attestations,
    }

    return manifest_dict