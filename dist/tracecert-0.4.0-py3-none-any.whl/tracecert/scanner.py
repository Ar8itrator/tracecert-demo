"""
tracecert/scanner.py

Phase 1 - Smart scanner with exclude patterns, max-files limit, and provenance tracking.
"""

import hashlib
from pathlib import Path
import json
from datetime import datetime
from typing import Optional
import click


def generate_trace(
    root_path: Path,
    output_trace: Path,
    max_files: int = 5000,
    exclude: Optional[str] = None,
    model: Optional[str] = None,
    prompt_file: Optional[str] = None,
) -> None:
    """Generate Agent Trace with smart filtering and AI provenance metadata."""
    root_path = Path(root_path).resolve()
    output_trace.parent.mkdir(parents=True, exist_ok=True)

    # Tamper-evident prompt hash (SHA-256 of prompt content)
    prompt_hash: Optional[str] = None
    if prompt_file and Path(prompt_file).exists():
        prompt_hash = hashlib.sha256(Path(prompt_file).read_bytes()).hexdigest()

    model_name = model or "claude"
    trace_records = []
    revision = "local-scan-" + datetime.utcnow().strftime("%Y%m%d%H%M%S")
    file_count = 0

    default_exclude = {".git", ".venv", "venv", "env", "node_modules", "__pycache__",
                       "build", "dist", ".tracecert", ".pytest_cache", ".mypy_cache",
                       "htmlcov", "coverage", "tests", "test"}
    user_exclude = set(exclude.split(",")) if exclude else set()
    exclude_dirs = default_exclude.union(user_exclude)

    click.echo(f"[scan] Python files (max {max_files:,}, skipping {len(exclude_dirs)} patterns)...", err=True)

    for py_file in root_path.rglob("*.py"):
        if file_count >= max_files:
            click.echo(f"[warn] Reached max_files limit ({max_files})", err=True)
            break

        if any(excluded in py_file.parts for excluded in exclude_dirs):
            continue

        try:
            content = py_file.read_text(encoding="utf-8", errors="ignore").strip()
            lines = len(content.splitlines())
            snippet = content[:850] if content else ""
            # Per-file content hash for tamper evidence
            content_hash = hashlib.sha256(content.encode()).hexdigest()

            metadata: dict = {
                "model": model_name,
                "content_hash": content_hash,
                "tracecert:level_attempted": 3,
            }
            if prompt_hash:
                metadata["prompt_hash"] = prompt_hash

            record = {
                "version": "0.1.0",
                "id": f"rec_{len(trace_records)+1:03d}",
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "vcs": {"type": "git", "revision": revision},
                "tool": {"name": model_name},
                "files": [{
                    "path": str(py_file.relative_to(root_path)),
                    "ai_generated": True,
                    "lines": lines,
                }],
                "content": snippet,
                "metadata": metadata,
            }
            trace_records.append(record)
            file_count += 1

        except Exception:
            continue

    with open(output_trace, "w", encoding="utf-8") as f:
        for record in trace_records:
            f.write(json.dumps(record) + "\n")

    click.echo(f"[ok] Generated trace with {len(trace_records)} files -> {output_trace}", err=True)