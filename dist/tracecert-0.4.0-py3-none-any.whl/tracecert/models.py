"""
tracecert/models.py

Simple Pydantic models compatible with your existing auditor.py and plugins.
"""

from typing import List, Dict, Any
from pydantic import BaseModel


class Attestation(BaseModel):
    """Individual attestation (used by your current auditor)."""
    predicateType: str
    predicate: Dict[str, Any]


class Certification(BaseModel):
    """Certification level and summary (used by your current auditor)."""
    highest_level: int
    levels_achieved: List[int]
    summary: Dict[str, Any] | None = None


class CertManifest(BaseModel):
    """Main TraceCert manifest (matches what your auditor currently builds)."""
    version: str = "1.0.0"
    repo_digest: str
    generated_at: str
    certification: Certification
    attestations: List[Dict[str, Any]]   # Keeping as dict list for maximum compatibility