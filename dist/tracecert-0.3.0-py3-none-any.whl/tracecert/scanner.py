"""
tracecert/scanner.py

Phase 1 - Smart scanner with exclude patterns and max-files limit
"""

from pathlib import Path
import json
from datetime import datetime
import click


def generate_trace(root_path: Path, output_trace: Path, max_files: int = 5000, exclude: str = None) -> None:
    """Generate Agent Trace with smart filtering."""
    root_path = Path(root_path)
    output_trace.parent.mkdir(parents=True, exist_ok=True)

    trace_records = []
    revision = "local-scan-" + datetime.utcnow().strftime("%Y%m%d%H%M%S")
    file_count = 0

    # Default exclusions
    default_exclude = {".git", ".venv", "venv", "env", "node_modules", "__pycache__", 
                       "build", "dist", ".tracecert", ".pytest_cache", ".mypy_cache", 
                       "htmlcov", "coverage", "tests", "test"}

    # User-provided exclusions
    user_exclude = set(exclude.split(",")) if exclude else set()
    exclude_dirs = default_exclude.union(user_exclude)

    click.echo(f"📄 Scanning Python files (max {max_files:,} files, skipping {len(exclude_dirs)} patterns)...")

    for py_file in root_path.rglob("*.py"):
        if file_count >= max_files:
            click.echo(f"⚠️  Reached max_files limit ({max_files})")
            break

        if any(excluded in py_file.parts for excluded in exclude_dirs):
            continue

        try:
            content = py_file.read_text(encoding="utf-8", errors="ignore").strip()
            lines = len(content.splitlines())
            snippet = content[:850] if content else ""

            record = {
                "version": "0.1.0",
                "id": f"rec_{len(trace_records)+1:03d}",
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "vcs": {"type": "git", "revision": revision},
                "tool": {"name": "claude"},
                "files": [{
                    "path": str(py_file.relative_to(root_path)),
                    "ai_generated": True,
                    "lines": lines
                }],
                "content": snippet,
                "metadata": {
                    "model": "claude-3.5-sonnet",
                    "tracecert:level_attempted": 3
                }
            }
            trace_records.append(record)
            file_count += 1

        except Exception:
            continue

    with open(output_trace, "w", encoding="utf-8") as f:
        for record in trace_records:
            f.write(json.dumps(record) + "\n")

    click.echo(f"✅ Generated trace with {len(trace_records)} files → {output_trace}")