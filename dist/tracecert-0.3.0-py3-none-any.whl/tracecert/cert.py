"""
tracecert/cert.py

Production-ready Sigstore keyless signing with graceful local fallback
"""

from pathlib import Path
import json
from datetime import datetime
from typing import Dict, Any

try:
    from sigstore.sign import Signer
    from sigstore.oidc import detect_credential
    SIGSTORE_AVAILABLE = True
except ImportError:
    SIGSTORE_AVAILABLE = False


def sign_manifest(manifest_dict: Dict[str, Any], output_path: Path) -> Dict[str, Any]:
    """Sign with real Sigstore when running in GitHub Actions, otherwise use local signature."""
    
    # Try Sigstore first (works automatically in GitHub Actions with OIDC)
    if SIGSTORE_AVAILABLE:
        try:
            credential = detect_credential()
            if credential:
                signer = Signer()
                payload = json.dumps(manifest_dict, sort_keys=True).encode("utf-8")
                result = signer.sign(input_=payload, identity_token=credential)

                signed_manifest = manifest_dict.copy()
                signed_manifest["signature"] = {
                    "type": "sigstore",
                    "bundle": result.bundle.to_json(),
                    "signed_at": datetime.utcnow().isoformat() + "Z",
                    "note": "Signed with Sigstore keyless signing via GitHub OIDC"
                }

                output_path.write_text(json.dumps(signed_manifest, indent=2))
                print("Manifest signed with Sigstore keyless signing (GitHub OIDC)")
                return signed_manifest

        except Exception as e:
            print(f"Sigstore signing attempt failed: {e}")

    # Fallback for local development
    from .cert_fallback import sign_manifest as fallback_sign
    signed = fallback_sign(manifest_dict, output_path)
    print("Manifest signed with local development signature")
    return signed