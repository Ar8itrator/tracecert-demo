"""
tracecert/cert_fallback.py
Clean local development signature
"""

import hashlib
import hmac
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any


def sign_manifest(manifest_dict: Dict[str, Any], output_path: Path) -> Dict[str, Any]:
    """Create a clean local development signature."""
    signed_manifest = manifest_dict.copy()

    payload = json.dumps(
        {k: v for k, v in signed_manifest.items() if k != "signature"}, 
        sort_keys=True
    ).encode("utf-8")

    secret = b"tracecert-mvp-dev-key-2026"
    signature_value = hmac.new(secret, payload, hashlib.sha256).hexdigest()

    signed_manifest["signature"] = {
        "type": "mvp",
        "algorithm": "HMAC-SHA256",
        "value": signature_value,
        "signed_at": datetime.utcnow().isoformat() + "Z",
        "note": "Local development signature (Sigstore not available in this environment)"
    }

    output_path.write_text(json.dumps(signed_manifest, indent=2))
    return signed_manifest