"""
tracecert/cli.py

Updated with --json support (Phase 3)
"""

import click
import json
from pathlib import Path

from .auditor import run_level_1_2_audit
from .cert import sign_manifest
from .scanner import generate_trace


@click.group()
@click.version_option(version="0.3.0")
def cli():
    """TraceCert — Making AI-generated software verifiable"""
    pass


@cli.command()
@click.argument("path", type=click.Path(exists=True, path_type=Path), default=".")
@click.option("--output", "-o", default=".tracecert/cert-manifest.json", type=click.Path(path_type=Path))
@click.option("--no-hipaa", is_flag=True, default=False, help="Disable HIPAA plugin")
@click.option("--json", "json_output", is_flag=True, default=False, help="Output full JSON manifest")
@click.option("--max-files", type=int, default=5000, help="Maximum number of files to scan")
@click.option("--exclude", default=None, help="Comma-separated directories to exclude (e.g. tests,docs)")
def scan(path: Path, output: Path, no_hipaa: bool, json_output: bool, max_files: int, exclude: str):
    """Scan a directory, generate trace, and certify it."""
    trace_file = Path(".tracecert/generated-trace.jsonl")
    trace_file.parent.mkdir(parents=True, exist_ok=True)

    click.echo(f"🔍 Scanning {path} ...")
    generate_trace(path, trace_file, max_files=max_files, exclude=exclude)

    click.echo("✅ Trace generated. Running certification...")
    return certify_from_trace(trace_file, output, no_hipaa, json_output)


@cli.command()
@click.argument("trace_file", type=click.Path(exists=True, path_type=Path))
@click.option("--output", "-o", default=".tracecert/cert-manifest.json", type=click.Path(path_type=Path))
@click.option("--no-hipaa", is_flag=True, default=False, help="Disable HIPAA plugin")
@click.option("--json", "json_output", is_flag=True, default=False, help="Output full JSON manifest instead of human-readable summary")
def certify(trace_file: Path, output: Path, no_hipaa: bool, json_output: bool):
    """Generate and sign a TraceCert manifest from an existing Agent Trace file."""
    return certify_from_trace(trace_file, output, no_hipaa, json_output)


def certify_from_trace(trace_file: Path, output: Path, no_hipaa: bool, json_output: bool):
    """Shared logic for both scan and certify."""
    output.parent.mkdir(parents=True, exist_ok=True)

    try:
        manifest_dict = run_level_1_2_audit(trace_file, enable_hipaa=not no_hipaa)
        signed_manifest = sign_manifest(manifest_dict, output)

        if json_output:
            click.echo(json.dumps(signed_manifest, indent=2))
            return

        # Human readable output (existing behavior)
        cert = signed_manifest["certification"]
        summary = cert.get("summary", {})

        click.echo("\n" + "="*80)
        click.echo("✅ TraceCert Manifest Generated and Signed")
        click.echo("="*80)
        click.echo(f"Level Achieved      : {cert.get('highest_level')}")
        click.echo(f"AI-Generated        : {summary.get('ai_percentage', 0)}% ({summary.get('lines_ai_generated', 0):,} lines)")
        click.echo(f"Compliance Score    : {summary.get('compliance_score', 0)}/100")
        click.echo(f"Records Processed   : {summary.get('records_processed', 0)}")
        click.echo(f"Unique Files        : {summary.get('unique_files', 0)}")
        click.echo(f"Secrets Found       : {summary.get('secrets_found', 0)}")
        click.echo(f"HIPAA Enabled       : {summary.get('hipaa_enabled', False)}")

        if cert.get('highest_level') >= 3:
            for att in signed_manifest.get("attestations", []):
                if "healthcare" in att.get("predicateType", "").lower():
                    pred = att.get("predicate", {})
                    click.echo(f"HIPAA Compliant     : {pred.get('compliant', False)}")
                    click.echo(f"HIPAA Risk Level    : {pred.get('risk_level', 'unknown').upper()}")
                    click.echo(f"HIPAA Score         : {pred.get('compliance_score', 0)}/100")
                    if pred.get("notes"):
                        click.echo(f"Notes               : {pred.get('notes')}")
                    break

        click.echo(f"Signature Type      : {signed_manifest.get('signature', {}).get('type', 'mvp').upper()}")
        click.echo(f"Output File         : {output}")
        click.echo("="*80)

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        raise click.ClickException(str(e))


if __name__ == "__main__":
    cli()