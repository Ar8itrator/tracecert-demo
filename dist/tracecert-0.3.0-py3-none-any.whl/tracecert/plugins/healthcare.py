"""
tracecert/plugins/healthcare.py

Polished final version - realistic scoring and clear notes
"""

from pathlib import Path
from typing import Dict, Any
from .base import Plugin


class HealthcarePlugin(Plugin):
    name = "Healthcare"
    domain = "healthcare"
    description = "HIPAA, PHI protection, audit logging, encryption, and clinical safety"

    # More realistic risky patterns
    RISKY_PHRASES = [
        "store patient", "save phi", "log patient", "send medical", "unencrypted",
        "plain text", "hardcode password", "password=", "secret=", "api_key=",
        "private_key", "insert into patients", "patient_data", "medical_record"
    ]

    def run(self, trace_file: Path, trace_data: Dict[str, Any]) -> Dict[str, Any]:
        raw = (trace_data.get("raw_content", "") + trace_data.get("content", "")).lower()

        risky_count = sum(1 for phrase in self.RISKY_PHRASES if phrase in raw)
        secrets_found = trace_data.get("secrets_found", 0)  # from auditor

        # Balanced scoring
        score = 92
        score -= risky_count * 12
        score -= secrets_found * 8
        compliance_score = max(40, min(100, round(score)))

        hipaa_compliant = compliance_score >= 75 and risky_count <= 2
        risk_level = "low" if compliance_score >= 85 else "medium" if compliance_score >= 65 else "high"

        notes = []
        if risky_count > 0:
            notes.append(f"⚠️ {risky_count} high-risk phrases detected")
        if secrets_found > 0:
            notes.append(f"{secrets_found} potential secrets found")
        if compliance_score < 70:
            notes.append("Significant improvements needed before healthcare use")
        elif compliance_score < 85:
            notes.append("Moderate improvements recommended")

        return {
            "hipaa_compliant": hipaa_compliant,
            "compliance_score": compliance_score,
            "risk_level": risk_level.upper(),
            "risky_prompts": risky_count,
            "secrets_found": secrets_found,
            "notes": " | ".join(notes) or "Clean trace - good baseline",
            "records_analyzed": len(trace_data.get("records", []))
        }

    def get_attestation(self, results: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "predicateType": "https://tracecert.dev/predicates/level3/healthcare/v1",
            "predicate": {
                "domain": "healthcare",
                "standard": "HIPAA + clinical safety",
                "compliant": results["hipaa_compliant"],
                "compliance_score": results["compliance_score"],
                "risk_level": results["risk_level"],
                "risky_prompts_detected": results["risky_prompts"],
                "secrets_found": results["secrets_found"],
                "notes": results["notes"],
                "records_analyzed": results["records_analyzed"]
            }
        }