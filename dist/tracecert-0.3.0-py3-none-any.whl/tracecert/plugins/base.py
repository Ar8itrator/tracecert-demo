"""
tracecert/plugins/base.py

Base class for plugins - compatible with your current auditor.py
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Any


class Plugin(ABC):
    """Base class for all TraceCert Level 3+ plugins."""

    name: str
    domain: str
    description: str

    @abstractmethod
    def run(self, trace_file: Path, trace_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run plugin-specific checks.
        trace_data contains parsed trace information (records, raw_content, etc.)
        """
        pass

    def get_attestation(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Return a Level 3 attestation (used by healthcare plugin)."""
        return {
            "predicateType": f"https://tracecert.dev/predicates/level3/{self.domain.lower()}/v1",
            "predicate": results
        }